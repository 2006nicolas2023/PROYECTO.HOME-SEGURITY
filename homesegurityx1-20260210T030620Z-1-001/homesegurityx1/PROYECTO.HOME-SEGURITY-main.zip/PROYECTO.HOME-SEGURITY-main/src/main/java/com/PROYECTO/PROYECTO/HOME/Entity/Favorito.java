package com.PROYECTO.PROYECTO.HOME.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "favorito")
public class Favorito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "vivienda_id")
    private Vivienda vivienda;

    public Favorito() {
    }

    public Favorito(Vivienda vivienda) {
        this.vivienda = vivienda;
    }

    public Long getId() {
        return id;
    }

    public Vivienda getVivienda() {
        return vivienda;
    }

    public void setVivienda(Vivienda vivienda) {
        this.vivienda = vivienda;
    }
}
