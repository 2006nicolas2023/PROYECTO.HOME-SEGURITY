package com.PROYECTO.PROYECTO.HOME.service.Impl;

import com.PROYECTO.PROYECTO.HOME.Entity.Citas;
import com.PROYECTO.PROYECTO.HOME.repository.CitasRepository;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoCita;
import com.PROYECTO.PROYECTO.HOME.service.CitasService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CitasServiceImpl implements CitasService {

    private final CitasRepository repo;

    public CitasServiceImpl(CitasRepository repo) {
        this.repo = repo;
    }

    @Override
    public Citas guardar(Citas citas) {
        return repo.save(citas);
    }

    @Override
    public List<Citas> listar() {
        return repo.findAll();
    }

    @Override
    public Citas obtenerPorId(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Citas actualizar(Long id, Citas datos) {
        Citas citas = repo.findById(id).orElse(null);
        if (citas == null) return null;
        citas.setFecha(datos.getFecha());
        citas.setHora(datos.getHora());
        citas.setLugar(datos.getLugar());
        citas.setVivienda(datos.getVivienda());

        return repo.save(citas);
    }

    @Override
    public void eliminar(Long id) {
        repo.deleteById(id);
    }

     @Override
    public Citas cambiarEstado(Long id, EstadoCita nuevoEstado) {
        Citas cita = repo.findById(id).orElse(null);
        if (cita == null) return null;

        return repo.save(cita);
    }
}
