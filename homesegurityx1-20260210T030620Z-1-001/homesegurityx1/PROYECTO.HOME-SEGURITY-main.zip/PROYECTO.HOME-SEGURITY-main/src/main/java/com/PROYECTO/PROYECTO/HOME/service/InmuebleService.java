package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Inmueble;
import java.util.List;

public interface InmuebleService {

    Inmueble guardar(Inmueble inmueble);

    List<Inmueble> listar();

    Inmueble buscarPorId(Long id);

    void eliminar(Long id);
}
