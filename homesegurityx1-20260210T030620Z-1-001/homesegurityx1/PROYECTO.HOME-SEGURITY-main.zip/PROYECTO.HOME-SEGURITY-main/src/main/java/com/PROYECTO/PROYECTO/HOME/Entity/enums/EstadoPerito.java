package com.PROYECTO.PROYECTO.HOME.Entity.enums;

public enum EstadoPerito {
    ACTIVO,
    INACTIVO
}