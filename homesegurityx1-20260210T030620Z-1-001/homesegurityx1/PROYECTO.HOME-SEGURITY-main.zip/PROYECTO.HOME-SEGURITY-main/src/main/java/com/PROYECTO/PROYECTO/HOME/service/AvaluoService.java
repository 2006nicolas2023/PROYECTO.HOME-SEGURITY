package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Avaluos;
import java.util.List;

public interface AvaluoService {
    Avaluos guardar(Avaluos avaluo);
    List<Avaluos> listar();
    Avaluos buscar(Long id);
}
