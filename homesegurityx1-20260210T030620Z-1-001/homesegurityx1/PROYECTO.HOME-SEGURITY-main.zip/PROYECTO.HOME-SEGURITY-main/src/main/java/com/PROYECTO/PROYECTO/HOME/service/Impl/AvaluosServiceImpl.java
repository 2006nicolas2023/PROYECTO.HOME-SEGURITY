package com.PROYECTO.PROYECTO.HOME.service.Impl;

import com.PROYECTO.PROYECTO.HOME.Entity.Avaluos;
import com.PROYECTO.PROYECTO.HOME.repository.AvaluosRepository;
import com.PROYECTO.PROYECTO.HOME.service.AvaluoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvaluosServiceImpl implements AvaluoService {

    private final AvaluosRepository repo;

    public AvaluosServiceImpl(AvaluosRepository repo) {
        this.repo = repo;
    }

    @Override
    public Avaluos guardar(Avaluos a) {
        return repo.save(a);
    }

    @Override
    public List<Avaluos> listar() {
        return repo.findAll();
    }

    @Override
    public Avaluos buscar(Long id) {
        return repo.findById(id).orElse(null);
    }
}
