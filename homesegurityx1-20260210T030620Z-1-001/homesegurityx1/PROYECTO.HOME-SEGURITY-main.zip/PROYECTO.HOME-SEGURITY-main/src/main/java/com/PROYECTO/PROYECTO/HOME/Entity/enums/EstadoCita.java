package com.PROYECTO.PROYECTO.HOME.Entity.enums;

public enum EstadoCita {
    PENDIENTE,
    COMPLETADO,
    FINALIZADO
}
