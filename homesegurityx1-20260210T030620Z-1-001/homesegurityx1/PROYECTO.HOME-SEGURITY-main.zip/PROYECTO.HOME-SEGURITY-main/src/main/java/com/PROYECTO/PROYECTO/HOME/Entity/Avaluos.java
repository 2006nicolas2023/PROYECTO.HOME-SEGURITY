package com.PROYECTO.PROYECTO.HOME.Entity;

import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoAvaluo;
import jakarta.persistence.*;

@Entity
@Table(name = "avaluos")
public class Avaluos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double areaTerreno;
    private Double areaConstruccion;
    private Integer antiguedad;

    private String estadoInmueble; 
    private String tipoAvaluo;     

    private String descripcion;
    private String foto;

    private Double valorEstimado;

    @Enumerated(EnumType.STRING)
    private EstadoAvaluo estado;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "perito_id")
    private Perito perito;

  

    public Long getId() { return id; }

    public Double getAreaTerreno() { return areaTerreno; }
    public void setAreaTerreno(Double areaTerreno) { this.areaTerreno = areaTerreno; }

    public Double getAreaConstruccion() { return areaConstruccion; }
    public void setAreaConstruccion(Double areaConstruccion) { this.areaConstruccion = areaConstruccion; }

    public Integer getAntiguedad() { return antiguedad; }
    public void setAntiguedad(Integer antiguedad) { this.antiguedad = antiguedad; }

    public String getEstadoInmueble() { return estadoInmueble; }
    public void setEstadoInmueble(String estadoInmueble) { this.estadoInmueble = estadoInmueble; }

    public String getTipoAvaluo() { return tipoAvaluo; }
    public void setTipoAvaluo(String tipoAvaluo) { this.tipoAvaluo = tipoAvaluo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }

    public Double getValorEstimado() { return valorEstimado; }
    public void setValorEstimado(Double valorEstimado) { this.valorEstimado = valorEstimado; }

    public EstadoAvaluo getEstado() { return estado; }
    public void setEstado(EstadoAvaluo estado) { this.estado = estado; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Perito getPerito() { return perito; }
    public void setPerito(Perito perito) { this.perito = perito; }
}
