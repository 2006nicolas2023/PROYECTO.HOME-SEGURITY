package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import java.util.List;

public interface ViviendaService {

    Vivienda findById(Long id);

    List<Vivienda> findAll();

    Vivienda save(Vivienda vivienda);

    void deleteById(Long id);

    List<Vivienda> listarViviendas();

    // 🔥 FILTRO (OBLIGATORIO PARA NO SALIR ROJO)
    List<Vivienda> filtro(
            String localidad,
            String estadoInmueble,
            String tipo,
            Integer habitaciones,
            Integer banos,
            Double metrosMin,
            Double metrosMax,
            Double precioMax
    );
}
