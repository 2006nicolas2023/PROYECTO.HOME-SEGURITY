package com.PROYECTO.PROYECTO.HOME.model;

import java.time.LocalDate;

public class SolicitudAvaluo {

    private Long id;
    private Double areaTerreno;
    private Double valorMetroTerreno;
    private Double areaConstruccion;
    private Double valorMetroConstruccion;
    private String descripcion;
    private LocalDate fecha;

    // getters setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getAreaTerreno() { return areaTerreno; }
    public void setAreaTerreno(Double areaTerreno) { this.areaTerreno = areaTerreno; }

    public Double getValorMetroTerreno() { return valorMetroTerreno; }
    public void setValorMetroTerreno(Double valorMetroTerreno) { this.valorMetroTerreno = valorMetroTerreno; }

    public Double getAreaConstruccion() { return areaConstruccion; }
    public void setAreaConstruccion(Double areaConstruccion) { this.areaConstruccion = areaConstruccion; }

    public Double getValorMetroConstruccion() { return valorMetroConstruccion; }
    public void setValorMetroConstruccion(Double valorMetroConstruccion) { this.valorMetroConstruccion = valorMetroConstruccion; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}
