package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Avaluos;
import com.PROYECTO.PROYECTO.HOME.Entity.Cliente;
import com.PROYECTO.PROYECTO.HOME.Entity.Perito;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoAvaluo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AvaluosRepository extends JpaRepository<Avaluos, Long> {

    List<Avaluos> findByEstado(EstadoAvaluo estado);
    List<Avaluos> findByPerito(Perito perito);
    List<Avaluos> findByCliente(Cliente cliente);
    List<Avaluos> findByEstado(String estado);
}
