package com.PROYECTO.PROYECTO.HOME.Entity.enums;

public enum TipoVivienda {
    CASA,
    APARTAMENTO,
    LOCAL,
    LOTE
}
