package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
