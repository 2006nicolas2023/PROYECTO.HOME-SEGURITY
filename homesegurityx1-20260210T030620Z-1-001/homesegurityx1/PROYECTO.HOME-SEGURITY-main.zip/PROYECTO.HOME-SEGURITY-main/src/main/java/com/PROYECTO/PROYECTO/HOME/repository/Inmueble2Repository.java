package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Inmueble;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Inmueble2Repository extends JpaRepository<Inmueble, Long> {
}

