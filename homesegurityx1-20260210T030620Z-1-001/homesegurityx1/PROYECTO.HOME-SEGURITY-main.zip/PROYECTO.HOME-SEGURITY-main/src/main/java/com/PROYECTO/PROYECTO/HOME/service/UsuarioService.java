package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import java.util.List;

public interface UsuarioService {

    // =========================
    // CRUD BÁSICO
    // =========================
    Usuarios guardar(Usuarios usuario);

    List<Usuarios> listar();

    Usuarios obtenerPoridUsuario(Long idUsuario);

    Usuarios actualizar(Long id, Usuarios usuarioActualizado);

    void eliminar(Long idUsuario);

    // =========================
    // BÚSQUEDAS
    // =========================
    List<Usuarios> buscarPorNombre(String nombre);

    List<Usuarios> buscarPorCorreoParcial(String correo);

    List<Usuarios> buscarPorEstado(String estado);

    Usuarios buscarPorCorreoExacto(String correo);

    // =========================
    // REPORTES
    // =========================
    byte[] generarReportePdf();
}
