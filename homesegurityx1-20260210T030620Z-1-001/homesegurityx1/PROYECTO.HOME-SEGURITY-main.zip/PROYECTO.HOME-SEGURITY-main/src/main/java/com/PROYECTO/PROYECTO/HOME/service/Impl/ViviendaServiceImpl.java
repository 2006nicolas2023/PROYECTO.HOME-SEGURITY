package com.PROYECTO.PROYECTO.HOME.service.Impl;

import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.repository.ViviendaRepository;
import com.PROYECTO.PROYECTO.HOME.service.ViviendaService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ViviendaServiceImpl implements ViviendaService {

    private final ViviendaRepository viviendaRepository;

    public ViviendaServiceImpl(ViviendaRepository viviendaRepository) {
        this.viviendaRepository = viviendaRepository;
    }

    @Override
    public Vivienda findById(Long id) {
        Optional<Vivienda> vivienda = viviendaRepository.findById(id);
        return vivienda.orElse(null);
    }

    @Override
    public List<Vivienda> findAll() {
        return viviendaRepository.findAll();
    }

    @Override
    public Vivienda save(Vivienda vivienda) {
        return viviendaRepository.save(vivienda);
    }

    @Override
    public void deleteById(Long id) {
        viviendaRepository.deleteById(id);
    }

    @Override
    public List<Vivienda> listarViviendas() {
        return findAll();
    }

    // =================================================
    // 🔥 FILTRO MULTICRITERIO (CORRECTO)
    // =================================================
    @Override
    public List<Vivienda> filtro(
            String localidad,
            String estadoInmueble,
            String tipo,
            Integer habitaciones,
            Integer banos,
            Double metrosMin,
            Double metrosMax,
            Double precioMax
    ) {

        return viviendaRepository.findAll().stream()

                // LOCALIDAD (String)
                .filter(v -> localidad == null || localidad.isEmpty()
                        || v.getLocalidad().equalsIgnoreCase(localidad))

                // ESTADO INMUEBLE (String ❗)
                .filter(v -> estadoInmueble == null || estadoInmueble.isEmpty()
                        || v.getEstadoInmueble().equalsIgnoreCase(estadoInmueble))

                // TIPO VIVIENDA (Enum ✅)
                .filter(v -> tipo == null || tipo.isEmpty()
                        || v.getTipo().name().equalsIgnoreCase(tipo))

                // HABITACIONES
                .filter(v -> habitaciones == null
                        || v.getHabitaciones().equals(habitaciones))

                // BAÑOS
                .filter(v -> banos == null
                        || v.getBanos().equals(banos))

                // METROS CUADRADOS
                .filter(v -> metrosMin == null
                        || v.getMetrosCuadrados() >= metrosMin)

                .filter(v -> metrosMax == null
                        || v.getMetrosCuadrados() <= metrosMax)

                // PRECIO (BigDecimal)
                .filter(v -> precioMax == null
                        || v.getPrecio().compareTo(BigDecimal.valueOf(precioMax)) <= 0)

                .collect(Collectors.toList());
    }
}
