package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Perito;
import java.util.List;

public interface PeritoService {

    Perito guardar(Perito perito);

    List<Perito> listar();

    Perito buscarPorId(Long id);

    void eliminar(Long id);
}
