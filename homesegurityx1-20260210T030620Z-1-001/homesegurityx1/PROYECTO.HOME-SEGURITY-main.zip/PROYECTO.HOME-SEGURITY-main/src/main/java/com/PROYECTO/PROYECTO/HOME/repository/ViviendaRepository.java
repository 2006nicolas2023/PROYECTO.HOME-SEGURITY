package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface ViviendaRepository extends JpaRepository<Vivienda, Long> {

    @Query("""
        SELECT v FROM Vivienda v
        WHERE (:habitaciones IS NULL OR v.habitaciones >= :habitaciones)
          AND (:banos IS NULL OR v.banos >= :banos)
          AND (:estado IS NULL OR :estado = '' OR v.estadoInmueble = :estado)
          AND (:direccion IS NULL OR LOWER(v.direccion) LIKE LOWER(CONCAT('%', :direccion, '%')))
          AND (:localidad IS NULL OR :localidad = '' OR LOWER(v.localidad) = LOWER(:localidad))
          AND (:precioMin IS NULL OR v.precio >= :precioMin)
          AND (:precioMax IS NULL OR v.precio <= :precioMax)
    """)
    List<Vivienda> buscar(
            @Param("habitaciones") Integer habitaciones,
            @Param("banos") Integer banos,
            @Param("estado") String estado,
            @Param("direccion") String direccion,
            @Param("localidad") String localidad,
            @Param("precioMin") BigDecimal precioMin,
            @Param("precioMax") BigDecimal precioMax
    );
}
