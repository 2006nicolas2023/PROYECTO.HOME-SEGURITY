package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Citas;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoCita;

import java.util.List;

public interface CitasService {

    Citas guardar(Citas cita);

    List<Citas> listar();

    Citas obtenerPorId(Long id);

    Citas actualizar(Long id, Citas datos);

    void eliminar(Long id);

    Citas cambiarEstado(Long id, EstadoCita nuevoEstado);

}
