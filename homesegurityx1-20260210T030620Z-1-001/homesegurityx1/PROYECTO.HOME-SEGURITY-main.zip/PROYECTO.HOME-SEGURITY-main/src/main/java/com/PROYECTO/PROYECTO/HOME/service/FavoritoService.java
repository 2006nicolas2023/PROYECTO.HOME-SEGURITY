package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Favorito;
import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.repository.FavoritoRepository;
import org.springframework.stereotype.Service;

@Service
public class FavoritoService {

    private final FavoritoRepository favoritoRepository;

    public FavoritoService(FavoritoRepository favoritoRepository) {
        this.favoritoRepository = favoritoRepository;
    }

    // ✅ AGREGAR A FAVORITOS
    public void agregarFavorito(Vivienda vivienda) {

        // Evitar duplicados
        boolean existe = favoritoRepository.existsByVivienda(vivienda);
        if (existe) {
            return;
        }

        Favorito favorito = new Favorito();
        favorito.setVivienda(vivienda);

        favoritoRepository.save(favorito);
    }

    // ✅ ELIMINAR DE FAVORITOS
    public void eliminarFavorito(Long id) {
        favoritoRepository.deleteById(id);
    }
}
