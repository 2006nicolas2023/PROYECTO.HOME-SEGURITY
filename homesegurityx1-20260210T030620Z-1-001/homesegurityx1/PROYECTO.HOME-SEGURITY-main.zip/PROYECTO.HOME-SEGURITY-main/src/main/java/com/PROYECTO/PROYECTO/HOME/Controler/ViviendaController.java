package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.*;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoAvaluo;
import com.PROYECTO.PROYECTO.HOME.repository.*;
import com.PROYECTO.PROYECTO.HOME.service.CitaService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class ViviendaController {

    private final ViviendaRepository viviendaRepository;
    private final CitaService citaService;
    private final CitasRepository citasRepository;
    private final AvaluosRepository avaluosRepository;
    private final ClienteRepository clienteRepository;
    private final FavoritoRepository favoritoRepository;

    public ViviendaController(
            ViviendaRepository viviendaRepository,
            CitaService citaService,
            CitasRepository citasRepository,
            AvaluosRepository avaluosRepository,
            ClienteRepository clienteRepository,
            FavoritoRepository favoritoRepository
    ) {
        this.viviendaRepository = viviendaRepository;
        this.citaService = citaService;
        this.citasRepository = citasRepository;
        this.avaluosRepository = avaluosRepository;
        this.clienteRepository = clienteRepository;
        this.favoritoRepository = favoritoRepository;
    }

    /* ===================== LISTAR VIVIENDAS ===================== */

    @GetMapping("/viviendas")
    public String listarViviendas(
            @RequestParam(required = false) String direccion,
            @RequestParam(required = false) Integer habitaciones,
            @RequestParam(required = false) Integer banos,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) String localidad,
            @RequestParam(required = false) Double precioMin,
            @RequestParam(required = false) Double precioMax,
            Model model
    ) {

        BigDecimal precioMinBD = (precioMin != null) ? BigDecimal.valueOf(precioMin) : null;
        BigDecimal precioMaxBD = (precioMax != null) ? BigDecimal.valueOf(precioMax) : null;

        List<Vivienda> viviendas = viviendaRepository.buscar(
                habitaciones,
                banos,
                estado,
                direccion,
                localidad,
                precioMinBD,
                precioMaxBD
        );

        if (viviendas.size() > 20) {
            viviendas = viviendas.subList(0, 20);
        }

        List<Favorito> favoritos = favoritoRepository.findAll();

        Set<Long> favoritosIds = favoritos.stream()
                .map(f -> f.getVivienda().getId())
                .collect(Collectors.toSet());

        model.addAttribute("viviendas", viviendas);
        model.addAttribute("favoritos", favoritos);
        model.addAttribute("favoritosIds", favoritosIds);

        return "admin/viviendas";
    }

    /* ===================== DETALLE USUARIO ===================== */

    @GetMapping("/usuario/vivienda/{id}")
    public String detalleUsuario(@PathVariable Long id, Model model) {

        Vivienda vivienda = viviendaRepository.findById(id).orElse(null);

        if (vivienda == null) {
            model.addAttribute("error", "Vivienda no encontrada");
            return "error";
        }

        List<String> imagenes = new ArrayList<>();

        if (vivienda.getImagenes() != null && !vivienda.getImagenes().isEmpty()) {
            imagenes = List.of(vivienda.getImagenes().split(","));
        }

        model.addAttribute("vivienda", vivienda);
        model.addAttribute("imagenes", imagenes);

        return "usuario_detalle_vivienda";
    }

    /* ===================== CITAS ===================== */

    @GetMapping("/vivienda/{id}/cita")
    public String formCita(@PathVariable Long id, Model model) {

        Vivienda vivienda = viviendaRepository.findById(id).orElse(null);
        Citas cita = new Citas();

        if (vivienda != null) {
            cita.setLugar(vivienda.getDireccion());
        }

        model.addAttribute("vivienda", vivienda);
        model.addAttribute("cita", cita);
        return "cita";
    }

    @PostMapping("/vivienda/{id}/cita")
    public String crearCita(
            @PathVariable Long id,
            @RequestParam String nombre,
            @RequestParam String telefono,
            @RequestParam String fecha,
            @RequestParam String hora,
            Model model
    ) {

        Vivienda vivienda = viviendaRepository.findById(id).orElse(null);

        if (vivienda == null) {
            model.addAttribute("error", "Vivienda no encontrada");
            return "cita";
        }

        Citas cita = new Citas();
        cita.setVivienda(vivienda);
        cita.setLugar(vivienda.getDireccion());
        cita.setFecha(LocalDate.parse(fecha));
        cita.setHora(LocalTime.parse(hora));

        try {
            citaService.crearCitaValidada(cita);
            return "cita_confirmacion";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("vivienda", vivienda);
            model.addAttribute("cita", cita);
            return "cita";
        }
    }

    /* ===================== REDIRECCIÓN AL CONFIRMAR ===================== */

    @GetMapping("/confirmar")
    public String confirmarYRedirigir() {
        return "redirect:/usuario/home";
    }

    /* ===================== AVALÚOS ===================== */

    @GetMapping("/avaluos/vivienda/nuevo")
    public String formularioAvaluo(Model model) {
        model.addAttribute("avaluo", new Avaluos());
        return "pedirAvaluo";
    }

    @PostMapping("/avaluos/vivienda/guardar")
    public String guardarAvaluo(
            @RequestParam String tipoAvaluo,
            @RequestParam Double valorEstimado,
            @RequestParam String estado,
            @RequestParam Long clienteId,
            Model model
    ) {

        Cliente cliente = clienteRepository.findById(clienteId).orElse(null);

        if (cliente == null) {
            model.addAttribute("error", "El cliente no existe");
            return "pedirAvaluo";
        }

        Avaluos avaluo = new Avaluos();
        avaluo.setTipoAvaluo(tipoAvaluo);
        avaluo.setValorEstimado(valorEstimado);
        avaluo.setEstado(EstadoAvaluo.valueOf(estado));
        avaluo.setCliente(cliente);

        avaluosRepository.save(avaluo);
        return "cita_confirmacion";
    }

    /* ===================== REGISTRO VIVIENDA ===================== */

    @GetMapping("/vivienda/registro")
    public String formularioVivienda(Model model) {
        model.addAttribute("vivienda", new Vivienda());
        return "registro_vivienda";
    }

    @PostMapping("/vivienda/guardar")
    public String guardarVivienda(
            @ModelAttribute Vivienda vivienda,
            @RequestParam("imagenesFiles") MultipartFile[] imagenesFiles
    ) {

        if (imagenesFiles != null && imagenesFiles.length > 0) {
            try {
                String carpeta = "src/main/resources/static/uploads/viviendas/";
                Files.createDirectories(Paths.get(carpeta));

                List<String> nombres = new ArrayList<>();

                for (MultipartFile img : imagenesFiles) {
                    if (!img.isEmpty()) {
                        String nombre = UUID.randomUUID() + "_" + img.getOriginalFilename();
                        Path ruta = Paths.get(carpeta, nombre);
                        Files.copy(img.getInputStream(), ruta, StandardCopyOption.REPLACE_EXISTING);
                        nombres.add(nombre);
                    }
                }

                vivienda.setImagenes(String.join(",", nombres));

            } catch (IOException e) {
                throw new RuntimeException("Error al guardar imágenes", e);
            }
        }

        viviendaRepository.save(vivienda);
        return "redirect:/admin/viviendas";
    }

    /* ===================== HISTORIAL CITAS ===================== */

    @GetMapping("/citas/historial")
    public String historialCitas(Model model) {
        model.addAttribute("citas", citasRepository.findAll());
        return "historialCita";
    }
}
