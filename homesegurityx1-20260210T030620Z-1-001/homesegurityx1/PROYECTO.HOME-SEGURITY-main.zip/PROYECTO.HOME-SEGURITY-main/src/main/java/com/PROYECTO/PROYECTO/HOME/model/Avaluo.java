package com.PROYECTO.PROYECTO.HOME.model;

import java.time.LocalDate;

public class Avaluo {

    private Long id;
    private String clienteNombre;
    private String direccion;
    private Double valor;
    private LocalDate fecha;

    private Double areaTerreno;
    private Double areaConstruccion;
    private Integer antiguedad;
    private String estadoInmueble;
    private String tipoAvaluo;
    private String descripcion;

    // ✅ agregado para evitar error get/set valorEstimado
    private Double valorEstimado;

    // getters y setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public Double getAreaTerreno() { return areaTerreno; }
    public void setAreaTerreno(Double areaTerreno) { this.areaTerreno = areaTerreno; }

    public Double getAreaConstruccion() { return areaConstruccion; }
    public void setAreaConstruccion(Double areaConstruccion) { this.areaConstruccion = areaConstruccion; }

    public Integer getAntiguedad() { return antiguedad; }
    public void setAntiguedad(Integer antiguedad) { this.antiguedad = antiguedad; }

    public String getEstadoInmueble() { return estadoInmueble; }
    public void setEstadoInmueble(String estadoInmueble) { this.estadoInmueble = estadoInmueble; }

    public String getTipoAvaluo() { return tipoAvaluo; }
    public void setTipoAvaluo(String tipoAvaluo) { this.tipoAvaluo = tipoAvaluo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    // ======= GET / SET AGREGADOS =======

    public Double getValorEstimado() {
        return valorEstimado;
    }

    public void setValorEstimado(Double valorEstimado) {
        this.valorEstimado = valorEstimado;
    }
}
