package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import com.PROYECTO.PROYECTO.HOME.service.UsuarioService;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import org.springframework.security.crypto.password.PasswordEncoder;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsuarioController {

    private final UsuarioService service;
    private final PasswordEncoder passwordEncoder;

public UsuarioController(UsuarioService service, PasswordEncoder passwordEncoder) {
    this.service = service;
    this.passwordEncoder = passwordEncoder;
}

    // -------------------------------
    // FORMULARIO DE REGISTRO
    // -------------------------------
    @GetMapping("/registro")
    public String registroForm(Model model) {
        model.addAttribute("usuario", new Usuarios());
        return "registro";
    }

    @PostMapping("/registrar")
    public String registrar(@ModelAttribute Usuarios usuario, HttpSession session) {
        if (usuario.getContraseña() == null || usuario.getContraseña().isEmpty()) {
            throw new IllegalArgumentException("La contraseña no puede ser vacía");
        }
        service.guardar(usuario);
        session.setAttribute("usuarioLogueado", usuario);

        String correo = usuario.getCorreo().toLowerCase();
        if (correo.endsWith("@perito.com") || correo.endsWith("@homesegurity.com") || correo.endsWith("@agentehome.com")) {
            return "login";
        }
        return "login";
    }

    // -------------------------------
    // LOGIN DE USUARIOS
    // -------------------------------
    @GetMapping("/login")
    public String loginForm(Model model) {
        model.addAttribute("usuario", new Usuarios());
        return "login";
    }

@PostMapping("/login")
public String loginUsuario(@RequestParam String correo,
                           @RequestParam("contrasena") String contrasena,
                           HttpSession session,
                           Model model) {

    Usuarios usuario = service.buscarPorCorreoExacto(correo);

    if (usuario != null &&
        passwordEncoder.matches(contrasena, usuario.getContraseña())) {

        session.setAttribute("usuarioLogueado", usuario);

        String email = correo.toLowerCase();
        if (email.contains("@gmail.com")) return "redirect:/usuario/home";
        if (email.endsWith("@perito.com")) return "redirect:/avaluos/dashboard";
        if (email.endsWith("@homesegurity.com") || email.endsWith("@agentehome.com"))
            return "redirect:/dashboard";

        return "redirect:/usuario/home";
    }

    model.addAttribute("error", "Correo o contraseña incorrectos");
    return "login";
}


    // -------------------------------
    // LISTAR USUARIOS (ADMIN)
    // -------------------------------
    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        model.addAttribute("usuariosFiltrados", service.listar());
        return "usuarios_filtros"; // Vista con filtros y opción PDF
    }


    // -------------------------------
    // FILTRO MULTICRITERIO PARA USUARIOS
    // -------------------------------
    @GetMapping("/usuarios/filtro")
    public String filtroUsuarios(@RequestParam(required = false) String nombre,
                                 @RequestParam(required = false) String correo,
                                 @RequestParam(required = false) String estado,
                                 Model model) {

        List<Usuarios> usuariosFiltrados = new ArrayList<>();

        if (nombre != null && !nombre.isEmpty()) {
            usuariosFiltrados = service.buscarPorNombre(nombre);
        } else if (correo != null && !correo.isEmpty()) {
            usuariosFiltrados = service.buscarPorCorreoParcial(correo);
        } else if (estado != null && !estado.isEmpty()) {
            usuariosFiltrados = service.buscarPorEstado(estado);
        } else {
            usuariosFiltrados = service.listar();
        }

        // Importante: enviamos los filtros al modelo para Thymeleaf
        model.addAttribute("usuariosFiltrados", usuariosFiltrados);
        model.addAttribute("nombre", nombre);
        model.addAttribute("correo", correo);
        model.addAttribute("estado", estado);

        return "usuarios_filtros"; // tu template
    }

    // -------------------------------
    // GENERAR PDF DE USUARIOS FILTRADOS
    // -------------------------------
    @GetMapping("/usuarios/pdf")
    public void generarPdfFiltrado(@RequestParam(required = false) String nombre,
                                   @RequestParam(required = false) String correo,
                                   @RequestParam(required = false) String estado,
                                   HttpServletResponse response) throws Exception {

        List<Usuarios> usuarios = new ArrayList<>();

        if (nombre != null && !nombre.isEmpty()) usuarios = service.buscarPorNombre(nombre);
        else if (correo != null && !correo.isEmpty()) usuarios = service.buscarPorCorreoParcial(correo);
        else if (estado != null && !estado.isEmpty()) usuarios = service.buscarPorEstado(estado);
        else usuarios = service.listar();

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=usuarios_filtrados.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        Paragraph titulo = new Paragraph("Reporte de Usuarios Filtrados")
                .setFontSize(18)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(titulo);

        Table tabla = new Table(UnitValue.createPercentArray(new float[]{1, 2, 2, 3, 2, 2}))
                .useAllAvailableWidth();

        String[] headers = {"ID", "Nombre", "Apellido", "Correo", "Documento", "Estado"};
        for (String h : headers) {
            Cell headerCell = new Cell()
                    .add(new Paragraph(h))
                    .setBackgroundColor(ColorConstants.LIGHT_GRAY)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER);
            tabla.addHeaderCell(headerCell);
        }

        for (Usuarios u : usuarios) {
            tabla.addCell(new Cell().add(new Paragraph(String.valueOf(u.getIdUsuario()))));
            tabla.addCell(new Cell().add(new Paragraph(u.getPrimerNombre())));
            tabla.addCell(new Cell().add(new Paragraph(u.getPrimerApellido())));
            tabla.addCell(new Cell().add(new Paragraph(u.getCorreo())));
            tabla.addCell(new Cell().add(new Paragraph(String.valueOf(u.getNum_documento()))));
            tabla.addCell(new Cell().add(new Paragraph(u.getEstadoCuenta())));
        }

        document.add(tabla);
        document.close();
    }

    // -------------------------------
    // LOGOUT
    // -------------------------------
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
