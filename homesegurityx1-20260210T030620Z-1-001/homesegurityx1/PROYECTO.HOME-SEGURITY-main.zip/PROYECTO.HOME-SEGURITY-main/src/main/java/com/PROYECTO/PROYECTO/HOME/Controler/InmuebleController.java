package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Inmueble;
import com.PROYECTO.PROYECTO.HOME.repository.InmuebleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/inmuebles")
public class InmuebleController {

    @Autowired
    private InmuebleRepository inmuebleRepository;

    @GetMapping
    public String listarInmuebles(Model model) {
        model.addAttribute("inmuebles", inmuebleRepository.findAll());
        return "inmuebles/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoInmueble(Model model) {
        model.addAttribute("inmueble", new Inmueble());
        return "inmuebles/formulario";
    }

    @PostMapping("/guardar")
    public String guardarInmueble(@ModelAttribute Inmueble inmueble) {
        inmuebleRepository.save(inmueble);
        return "redirect:/inmuebles";
    }

    @GetMapping("/editar/{id}")
    public String editarInmueble(@PathVariable Integer id, Model model) {
        model.addAttribute("inmueble", inmuebleRepository.findById(id).orElse(null));
        return "inmuebles/formulario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarInmueble(@PathVariable Integer id) {
        inmuebleRepository.deleteById(id);
        return "redirect:/inmuebles";
    }
}
