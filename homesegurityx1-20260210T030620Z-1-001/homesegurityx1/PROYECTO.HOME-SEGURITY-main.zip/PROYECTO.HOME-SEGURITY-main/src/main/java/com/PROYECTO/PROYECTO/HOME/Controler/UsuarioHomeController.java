package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Pago;
import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.repository.PagoRepository;
import com.PROYECTO.PROYECTO.HOME.service.ViviendaService;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsuarioHomeController {

    private final ViviendaService viviendaService;
    private final PagoRepository pagoRepository;

    public UsuarioHomeController(ViviendaService viviendaService,
                                 PagoRepository pagoRepository) {
        this.viviendaService = viviendaService;
        this.pagoRepository = pagoRepository;
    }

   
    @GetMapping("/usuario/home")
    public String homeUsuario(HttpSession session, Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        model.addAttribute("usuario", usuario);
        model.addAttribute("viviendas", viviendaService.listarViviendas());

        return "usuario_home";
    }

    
    @GetMapping("/usuario/cuenta")
    public String cuentaUsuario(HttpSession session, Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        model.addAttribute("usuario", usuario);
        return "usuario/cuenta";
    }

    
    @GetMapping("/usuario/quienes-somos")
    public String quienesSomosUsuario(HttpSession session, Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        model.addAttribute("usuario", usuario);
        return "usuario/quienes-somos";
    }

    
    @GetMapping("/usuario/favoritos")
    public String verFavoritos(HttpSession session, Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        List<Vivienda> favoritos =
                (List<Vivienda>) session.getAttribute("favoritos");

        if (favoritos == null) favoritos = new ArrayList<>();

        model.addAttribute("usuario", usuario);
        model.addAttribute("favoritos", favoritos);

        return "usuario/favoritos";
    }

   
    @GetMapping("/usuario/favoritos/agregar/{id}")
    public String agregarFavorito(@PathVariable Long id, HttpSession session) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        List<Vivienda> favoritos =
                (List<Vivienda>) session.getAttribute("favoritos");

        if (favoritos == null) favoritos = new ArrayList<>();

        Vivienda vivienda = viviendaService.listarViviendas()
                .stream()
                .filter(v -> v.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (vivienda != null && !favoritos.contains(vivienda)) {
            favoritos.add(vivienda);
        }

        session.setAttribute("favoritos", favoritos);
        return "redirect:/usuario/home";
    }

    @GetMapping("/usuario/favoritos/eliminar/{id}")
    public String eliminarFavorito(@PathVariable Long id, HttpSession session) {

        List<Vivienda> favoritos =
                (List<Vivienda>) session.getAttribute("favoritos");

        if (favoritos != null) {
            favoritos.removeIf(v -> v.getId().equals(id));
        }

        session.setAttribute("favoritos", favoritos);
        return "redirect:/usuario/favoritos";
    }

  
    @GetMapping("/usuario/pago/{id}")
    public String pagoVivienda(@PathVariable Long id,
                               HttpSession session,
                               Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        Vivienda vivienda = viviendaService.listarViviendas()
                .stream()
                .filter(v -> v.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (vivienda == null) return "redirect:/usuario/home";

        model.addAttribute("usuario", usuario);
        model.addAttribute("vivienda", vivienda);

        return "usuario/pago";
    }

    @PostMapping("/usuario/pago/guardar")
    public String guardarPago(
            @RequestParam String metodoPago,
            @RequestParam Double total,
            @RequestParam(required = false) Double cuota,
            @RequestParam(required = false) Integer meses,
            @RequestParam Long viviendaId,
            HttpSession session) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        Vivienda vivienda = viviendaService.listarViviendas()
                .stream()
                .filter(v -> v.getId().equals(viviendaId))
                .findFirst()
                .orElse(null);

        if (vivienda == null) return "redirect:/usuario/home";

        Pago pago = new Pago();
        pago.setMetodoPago(metodoPago);
        pago.setValorTotal(total);
        pago.setCuotaMensual(cuota);
        pago.setMeses(meses);
        pago.setUsuario(usuario);
        pago.setVivienda(vivienda);

        pagoRepository.save(pago);

        return "redirect:/usuario/home";
    }


    @GetMapping("/usuario/historial/agregar/{id}")
    public String agregarHistorial(@PathVariable Long id, HttpSession session) {

        List<Vivienda> historial =
                (List<Vivienda>) session.getAttribute("historial");

        if (historial == null) historial = new ArrayList<>();

        Vivienda vivienda = viviendaService.listarViviendas()
                .stream()
                .filter(v -> v.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (vivienda != null) {
            historial.removeIf(v -> v.getId().equals(id));
            historial.add(0, vivienda);
        }

        session.setAttribute("historial", historial);

        return "redirect:/usuario/home";
    }

    @GetMapping("/usuario/historial")
    public String verHistorial(HttpSession session, Model model) {

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/login";

        List<Vivienda> historial =
                (List<Vivienda>) session.getAttribute("historial");

        if (historial == null) historial = new ArrayList<>();

        model.addAttribute("usuario", usuario);
        model.addAttribute("historial", historial);

        return "usuario/historial";
    }

    @GetMapping("/usuario/historial/borrar")
    public String borrarHistorial(HttpSession session) {

        session.removeAttribute("historial");
        return "redirect:/usuario/historial";
    }
}
