package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuarios, Long> {

    // ================= LOGIN =================
    Optional<Usuarios> findByCorreo(String correo);

    // ================= FILTROS =================
    List<Usuarios> findByCorreoContainingIgnoreCase(String correo);

    List<Usuarios> findByPrimerNombreContainingIgnoreCase(String primerNombre);

    List<Usuarios> findByEstadoCuentaContainingIgnoreCase(String estadoCuenta);

    // ================= GESTIÓN USUARIOS =================
    @Modifying
    @Query("UPDATE Usuarios u SET u.estadoCuenta = :estado WHERE u.idUsuario = :id")
    void actualizarEstadoCuenta(@Param("id") Long id,
                                @Param("estado") String estado);
}
