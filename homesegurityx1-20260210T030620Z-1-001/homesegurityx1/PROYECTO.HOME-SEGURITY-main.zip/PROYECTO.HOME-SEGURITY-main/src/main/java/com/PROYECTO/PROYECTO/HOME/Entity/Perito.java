package com.PROYECTO.PROYECTO.HOME.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.util.List;

@Entity
@Table(name = "perito")
public class Perito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_perito")
    private Long idPerito;

    @NotBlank(message = "El registro RAA es obligatorio")
    @Column(name = "registro_raa", nullable = false)
    private String registroRAA;

    @NotBlank(message = "La categoría es obligatoria")
    @Column(name = "categoria_especializacion", nullable = false)
    private String categoriaEspecializacion;

    @NotBlank(message = "La formación académica es obligatoria")
    @Column(name = "formacion_academica", nullable = false)
    private String formacionAcademica;

    @NotBlank(message = "La experiencia es obligatoria")
    @Pattern(regexp = "^[0-9]{1,2}$", message = "La experiencia debe ser un número (años)")
    @Column(name = "experiencia_anios", nullable = false)
    private String experienciaAnios;

    @NotBlank(message = "La dirección es obligatoria")
    @Size(min = 5, max = 150, message = "La dirección debe tener entre 5 y 150 caracteres")
    @Column(name = "direccion_oficina", nullable = false)
    private String direccionOficina;

    @OneToMany(mappedBy = "perito")
    private List<Avaluos> avaluos;

    public Long getIdPerito() { return idPerito; }
    public void setIdPerito(Long idPerito) { this.idPerito = idPerito; }

    public String getRegistroRAA() { return registroRAA; }
    public void setRegistroRAA(String registroRAA) { this.registroRAA = registroRAA; }

    public String getCategoriaEspecializacion() { return categoriaEspecializacion; }
    public void setCategoriaEspecializacion(String categoriaEspecializacion) { this.categoriaEspecializacion = categoriaEspecializacion; }

    public String getFormacionAcademica() { return formacionAcademica; }
    public void setFormacionAcademica(String formacionAcademica) { this.formacionAcademica = formacionAcademica; }

    public String getExperienciaAnios() { return experienciaAnios; }
    public void setExperienciaAnios(String experienciaAnios) { this.experienciaAnios = experienciaAnios; }

    public String getDireccionOficina() { return direccionOficina; }
    public void setDireccionOficina(String direccionOficina) { this.direccionOficina = direccionOficina; }

    public List<Avaluos> getAvaluos() { return avaluos; }
    public void setAvaluos(List<Avaluos> avaluos) { this.avaluos = avaluos; }
}
