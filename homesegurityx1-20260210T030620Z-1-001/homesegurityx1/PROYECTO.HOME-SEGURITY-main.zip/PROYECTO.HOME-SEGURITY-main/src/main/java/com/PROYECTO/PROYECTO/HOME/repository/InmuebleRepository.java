package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Inmueble;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InmuebleRepository extends JpaRepository<Inmueble, Integer> {
       long countByEstado(String estado);
}
