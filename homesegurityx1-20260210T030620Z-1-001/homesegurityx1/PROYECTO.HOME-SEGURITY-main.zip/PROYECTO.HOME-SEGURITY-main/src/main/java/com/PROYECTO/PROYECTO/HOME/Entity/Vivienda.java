package com.PROYECTO.PROYECTO.HOME.Entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.TipoVivienda;

@Entity
@Table(name = "vivienda")
public class Vivienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_vivienda")
    private Long id;

    @Column(name = "metros_cuadrados")
    private Double metrosCuadrados;

    @Column(name = "habitaciones")
    private Integer habitaciones;

    @Column(name = "banos")
    private Integer banos;

    @Column(name = "localidad")
    private String localidad;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo", nullable = false)
    private TipoVivienda tipo;

    @Column(name = "estado_inmueble")
    private String estadoInmueble;

    @Column(name = "valor_propiedad", precision = 15, scale = 2)
    private BigDecimal valorPropiedad;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "valor_construccion", precision = 15, scale = 2)
    private BigDecimal valorConstruccion;

    @Column(name = "precio", precision = 15, scale = 2, nullable = false)
    private BigDecimal precio;

    @Column(name = "imagenes")
    private String imagenes; // img1.jpg,img2.jpg,img3.jpg

    @ManyToOne
    @JoinColumn(name = "id_asesoramiento")
    private Asesoramiento asesoramiento;

    @ManyToOne
    @JoinColumn(name = "id_avaluo")
    private Avaluos avaluo;

    // ===== GETTERS & SETTERS =====

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(Double metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    public Integer getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Integer habitaciones) {
        this.habitaciones = habitaciones;
    }

    public Integer getBanos() {
        return banos;
    }

    public void setBanos(Integer banos) {
        this.banos = banos;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public TipoVivienda getTipo() {
        return tipo;
    }

    public void setTipo(TipoVivienda tipo) {
        this.tipo = tipo;
    }

    public String getEstadoInmueble() {
        return estadoInmueble;
    }

    public void setEstadoInmueble(String estadoInmueble) {
        this.estadoInmueble = estadoInmueble;
    }

    public BigDecimal getValorPropiedad() {
        return valorPropiedad;
    }

    public void setValorPropiedad(BigDecimal valorPropiedad) {
        this.valorPropiedad = valorPropiedad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public BigDecimal getValorConstruccion() {
        return valorConstruccion;
    }

    public void setValorConstruccion(BigDecimal valorConstruccion) {
        this.valorConstruccion = valorConstruccion;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public String getImagenes() {
        return imagenes;
    }

    public void setImagenes(String imagenes) {
        this.imagenes = imagenes;
    }

    public Asesoramiento getAsesoramiento() {
        return asesoramiento;
    }

    public void setAsesoramiento(Asesoramiento asesoramiento) {
        this.asesoramiento = asesoramiento;
    }

    public Avaluos getAvaluo() {
        return avaluo;
    }

    public void setAvaluo(Avaluos avaluo) {
        this.avaluo = avaluo;
    }
}
