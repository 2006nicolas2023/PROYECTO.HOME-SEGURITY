package com.PROYECTO.PROYECTO.HOME.Controler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.repository.FavoritoRepository;
import com.PROYECTO.PROYECTO.HOME.repository.ViviendaRepository;
import com.PROYECTO.PROYECTO.HOME.Entity.Favorito;




@Controller
@RequestMapping("/favoritos")
public class FavoritoController {

    private final FavoritoRepository favoritoRepository;
    private final ViviendaRepository viviendaRepository;

    public FavoritoController(FavoritoRepository favoritoRepository,
                              ViviendaRepository viviendaRepository) {
        this.favoritoRepository = favoritoRepository;
        this.viviendaRepository = viviendaRepository;
    }

    // ⭐ AGREGAR FAVORITO
    @GetMapping("/agregar/{id}")
    public String agregarFavorito(@PathVariable Long id) {

        Vivienda vivienda = viviendaRepository.findById(id).orElse(null);
        if (vivienda != null) {

            boolean existe = favoritoRepository.existsByVivienda(vivienda);
            if (!existe) {
                Favorito favorito = new Favorito();
                favorito.setVivienda(vivienda);
                favoritoRepository.save(favorito);
            }
        }
        return "redirect:/admin/viviendas";
    }

    // ❌ ELIMINAR FAVORITO
    @GetMapping("/eliminar/{id}")
    public String eliminarFavorito(@PathVariable Long id) {
        favoritoRepository.deleteById(id);
        return "redirect:/admin/viviendas";
    }
}
