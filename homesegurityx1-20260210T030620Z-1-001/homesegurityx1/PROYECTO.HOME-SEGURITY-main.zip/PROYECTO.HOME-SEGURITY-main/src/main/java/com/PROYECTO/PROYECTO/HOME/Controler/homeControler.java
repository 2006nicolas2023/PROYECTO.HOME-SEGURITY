package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.repository.ViviendaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class homeControler {

    private final ViviendaRepository viviendaRepository;

    public homeControler(ViviendaRepository viviendaRepository) {
        this.viviendaRepository = viviendaRepository;
    }

    // =========================
    // HOME / INDEX
    // =========================
    @GetMapping("/")
    public String home(
            @RequestParam(required = false) String direccion,
            @RequestParam(required = false) Integer habitaciones,
            @RequestParam(required = false) Integer banos,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) String localidad,
            @RequestParam(required = false) Double precioMin,
            @RequestParam(required = false) Double precioMax,
            Model model
    ) {

        BigDecimal precioMinBD = (precioMin != null) ? BigDecimal.valueOf(precioMin) : null;
        BigDecimal precioMaxBD = (precioMax != null) ? BigDecimal.valueOf(precioMax) : null;

        List<Vivienda> viviendas;

        if (direccion == null &&
            habitaciones == null &&
            banos == null &&
            estado == null &&
            localidad == null &&
            precioMinBD == null &&
            precioMaxBD == null) {

            viviendas = viviendaRepository.findAll();

        } else {
            viviendas = viviendaRepository.buscar(
                    habitaciones,
                    banos,
                    estado,
                    direccion,
                    localidad,
                    precioMinBD,
                    precioMaxBD
            );
        }

        model.addAttribute("viviendas", viviendas);
        return "index";
    }

    // =========================
    // QUIÉNES SOMOS
    // =========================
    @GetMapping("/quienes-somos")
    public String quienesSomos() {
        return "quienes-somos";
    }
}
