package com.PROYECTO.PROYECTO.HOME.service.Impl;

import com.PROYECTO.PROYECTO.HOME.Entity.Inmueble;
import com.PROYECTO.PROYECTO.HOME.repository.Inmueble2Repository;
import com.PROYECTO.PROYECTO.HOME.service.InmuebleService;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InmuebleServiceImpl implements InmuebleService {

    private final Inmueble2Repository inmuebleRepository;

    public InmuebleServiceImpl(Inmueble2Repository inmuebleRepository) {
        this.inmuebleRepository = inmuebleRepository;
    }

    @Override
    public Inmueble guardar(Inmueble inmueble) {
        return inmuebleRepository.save(inmueble);
    }

    @Override
    public List<Inmueble> listar() {
        return inmuebleRepository.findAll();
    }

    @Override
    public Inmueble buscarPorId(Long id) {
        return inmuebleRepository.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Long id) {
        inmuebleRepository.deleteById(id);
    }
}
