package com.PROYECTO.PROYECTO.HOME.service.Impl;



import com.PROYECTO.PROYECTO.HOME.Entity.Perito;
import com.PROYECTO.PROYECTO.HOME.repository.PeritoRepository;
import com.PROYECTO.PROYECTO.HOME.service.PeritoService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PeritoServiceImpl implements PeritoService {

    private final PeritoRepository peritoRepository;

    public PeritoServiceImpl(PeritoRepository peritoRepository) {
        this.peritoRepository = peritoRepository;
    }

    @Override
    public Perito guardar(Perito perito) {
        return peritoRepository.save(perito);
    }

    @Override
    public List<Perito> listar() {
        return peritoRepository.findAll();
    }

    @Override
    public Perito buscarPorId(Long id) {
        return peritoRepository.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Long id) {
        peritoRepository.deleteById(id);
    }
}
