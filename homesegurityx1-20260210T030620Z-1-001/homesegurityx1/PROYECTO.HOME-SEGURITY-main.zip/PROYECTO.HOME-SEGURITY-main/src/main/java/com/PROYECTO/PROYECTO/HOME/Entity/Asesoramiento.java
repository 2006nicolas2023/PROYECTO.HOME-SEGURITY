package com.PROYECTO.PROYECTO.HOME.Entity;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoAsesoramiento;


import jakarta.persistence.*;

@Entity
@Table(name = "Asesoramiento")
public class Asesoramiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_asesoramiento")
    private Long id;

    private String Observaciones_visita;
    private String Tipo_asesoramiento;

    @Enumerated(EnumType.STRING)
    private EstadoAsesoramiento Estado;


    @ManyToOne
    @JoinColumn(name = "id_agente_inmobiliario")
    private AgenteInmobiliario agente;

    @ManyToOne
    @JoinColumn(name = "id_citas")
    private Citas citas;
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getObservaciones_visita() {
        return Observaciones_visita;
    }

    public void setObservaciones_visita(String observaciones_visita) {
        Observaciones_visita = observaciones_visita;
    }

    public String getTipo_asesoramiento() {
        return Tipo_asesoramiento;
    }

    public void setTipo_asesoramiento(String tipo_asesoramiento) {
        Tipo_asesoramiento = tipo_asesoramiento;
    }

    public EstadoAsesoramiento getEstado() {
        return Estado;
    }
    
    public void setEstado(EstadoAsesoramiento estado) {
        Estado = estado;
    }

    public AgenteInmobiliario getAgente() {
        return agente;
    }

    public void setAgente(AgenteInmobiliario agente) {
        this.agente = agente;
    }

    public Citas getCitas() {
        return citas;
    }

    public void setCitas(Citas citas) {
        this.citas = citas;
    }

}
