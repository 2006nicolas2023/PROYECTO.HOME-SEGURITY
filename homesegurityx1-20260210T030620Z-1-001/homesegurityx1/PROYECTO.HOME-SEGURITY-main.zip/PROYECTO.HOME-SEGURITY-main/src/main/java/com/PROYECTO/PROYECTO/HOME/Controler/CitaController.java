package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Citas;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoCita;
import com.PROYECTO.PROYECTO.HOME.service.*;
import com.PROYECTO.PROYECTO.HOME.service.ViviendaService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/citas")
public class CitaController {

    private final CitasService citaService;
    private final ViviendaService viviendaService;

    public CitaController(CitasService citaService, ViviendaService viviendaService) {
        this.citaService = citaService;
        this.viviendaService = viviendaService;
    }

    // Redirigir /admin/citas a historial
    @GetMapping("")
    public String redirectCitas() {
        return "redirect:/admin/citas/historial";
    }

    // Listar todas las citas
    @GetMapping("/historial")
    public String listarCitas(Model model) {
        model.addAttribute("citas", citaService.listar());
        return "admin/citas/citas_historial";
    }

    // Mostrar formulario para nueva cita asociada a una vivienda
    @GetMapping("/nuevo/{viviendaId}")
    public String nuevaCita(@PathVariable Long viviendaId, Model model) {
        Citas cita = new Citas();
        cita.setVivienda(viviendaService.findById(viviendaId));
        model.addAttribute("cita", cita);
        return "admin/citas/admin_cita_form";
    }

    // Guardar nueva cita
    @PostMapping("/guardar")
    public String guardarCita(@ModelAttribute Citas cita) {
        citaService.guardar(cita);
        return "redirect:/admin/citas/historial";
    }

    // Mostrar formulario para editar cita
    @GetMapping("/editar/{id}")
    public String editarCita(@PathVariable Long id, Model model) {
        model.addAttribute("cita", citaService.obtenerPorId(id));
        return "admin/citas/admin_cita_form";
    }

    // Actualizar cita existente
    @PostMapping("/actualizar/{id}")
    public String actualizarCita(@PathVariable Long id, @ModelAttribute Citas cita) {
        citaService.actualizar(id, cita);
        return "redirect:/admin/citas/historial";
    }

    // Eliminar cita
    @GetMapping("/eliminar/{id}")
    public String eliminarCita(@PathVariable Long id) {
        citaService.eliminar(id);
        return "redirect:/admin/citas/historial";
    }

    // 🔹 Cambiar estado de la cita
    @GetMapping("/cambiar-estado/{id}/{nuevoEstado}")
    public String cambiarEstado(@PathVariable Long id, @PathVariable String nuevoEstado) {
        EstadoCita estado;
        try {
            estado = EstadoCita.valueOf(nuevoEstado.toUpperCase()); // Convierte string a enum
        } catch (IllegalArgumentException e) {
            // Si el estado no es válido, redirige al historial sin cambios
            return "redirect:/admin/citas/historial";
        }

        citaService.cambiarEstado(id, estado);
        return "redirect:/admin/citas/historial";
    }
}
