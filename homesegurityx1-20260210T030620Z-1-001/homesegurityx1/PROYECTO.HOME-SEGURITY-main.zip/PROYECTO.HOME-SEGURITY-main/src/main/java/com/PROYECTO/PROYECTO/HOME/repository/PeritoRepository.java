package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Perito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PeritoRepository extends JpaRepository<Perito, Long> {
}
