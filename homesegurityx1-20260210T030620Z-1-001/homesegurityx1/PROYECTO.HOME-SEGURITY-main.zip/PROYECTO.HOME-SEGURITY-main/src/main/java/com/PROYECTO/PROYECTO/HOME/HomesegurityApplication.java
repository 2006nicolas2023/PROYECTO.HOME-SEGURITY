package com.PROYECTO.PROYECTO.HOME;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.PROYECTO")
public class HomesegurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(HomesegurityApplication.class, args);
    }
}
