package com.PROYECTO.PROYECTO.HOME.service.Impl;

import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import com.PROYECTO.PROYECTO.HOME.repository.UsuarioRepository;
import com.PROYECTO.PROYECTO.HOME.service.UsuarioService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioServiceImpl(
            UsuarioRepository usuarioRepository,
            PasswordEncoder passwordEncoder) {

        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // =========================
    // REGISTRAR / GUARDAR USUARIO
    // =========================
    @Override
    public Usuarios guardar(Usuarios usuario) {

        if (usuario.getContraseña() == null || usuario.getContraseña().isEmpty()) {
            throw new IllegalArgumentException("La contraseña no puede ser vacía");
        }

        // 🔐 Encriptar solo si no está encriptada
        if (!usuario.getContraseña().startsWith("$2a$")) {
            usuario.setContraseña(
                    passwordEncoder.encode(usuario.getContraseña())
            );
        }

        return usuarioRepository.save(usuario);
    }

    // =========================
    // LISTAR
    // =========================
    @Override
    public List<Usuarios> listar() {
        return usuarioRepository.findAll();
    }

    // =========================
    // BUSCAR POR ID
    // =========================
    @Override
    public Usuarios obtenerPoridUsuario(Long idUsuario) {
        return usuarioRepository.findById(idUsuario).orElse(null);
    }

    // =========================
    // ACTUALIZAR
    // =========================
    @Override
    public Usuarios actualizar(Long id, Usuarios usuarioActualizado) {

        Usuarios usuario = usuarioRepository.findById(id).orElse(null);

        if (usuario == null) {
            return null;
        }

        usuario.setPrimerNombre(usuarioActualizado.getPrimerNombre());
        usuario.setPrimerApellido(usuarioActualizado.getPrimerApellido());
        usuario.setCorreo(usuarioActualizado.getCorreo());
        usuario.setTelefono(usuarioActualizado.getTelefono());
        usuario.setEstadoCuenta(usuarioActualizado.getEstadoCuenta());
        usuario.setEdad(usuarioActualizado.getEdad());
        usuario.setDireccion(usuarioActualizado.getDireccion());
        usuario.setNum_documento(usuarioActualizado.getNum_documento());

        if (usuarioActualizado.getContraseña() != null &&
            !usuarioActualizado.getContraseña().isEmpty()) {

            usuario.setContraseña(
                    passwordEncoder.encode(usuarioActualizado.getContraseña())
            );
        }

        return usuarioRepository.save(usuario);
    }

    // =========================
    // ELIMINAR
    // =========================
    @Override
    public void eliminar(Long idUsuario) {
        usuarioRepository.deleteById(idUsuario);
    }

    // =========================
    // BÚSQUEDAS
    // =========================
    @Override
    public List<Usuarios> buscarPorNombre(String nombre) {
        return usuarioRepository.findByPrimerNombreContainingIgnoreCase(nombre);
    }

    @Override
    public List<Usuarios> buscarPorCorreoParcial(String correo) {
        return usuarioRepository.findByCorreoContainingIgnoreCase(correo);
    }

    @Override
    public List<Usuarios> buscarPorEstado(String estado) {
        return usuarioRepository.findByEstadoCuentaContainingIgnoreCase(estado);
    }

    @Override
    public Usuarios buscarPorCorreoExacto(String correo) {
        return usuarioRepository.findByCorreo(correo).orElse(null);
    }

    // =========================
    // PDF (NO IMPLEMENTADO)
    // =========================
    @Override
    public byte[] generarReportePdf() {
        return new byte[0];
    }
}
