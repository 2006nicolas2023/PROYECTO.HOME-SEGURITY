package com.PROYECTO.PROYECTO.HOME.Entity.enums;

public enum EstadoAvaluo {
    PENDIENTE,
    APROBADO,
    ASIGNADO,
    EN_PROCESO,
    COMPLETADO,
    RECHAZADO
}
