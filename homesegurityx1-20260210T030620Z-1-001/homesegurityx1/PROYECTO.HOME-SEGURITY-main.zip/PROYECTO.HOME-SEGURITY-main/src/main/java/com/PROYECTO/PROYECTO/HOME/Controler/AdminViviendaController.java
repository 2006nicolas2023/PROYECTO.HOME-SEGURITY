package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Vivienda;
import com.PROYECTO.PROYECTO.HOME.Entity.Favorito;
import com.PROYECTO.PROYECTO.HOME.service.ViviendaService;
import com.PROYECTO.PROYECTO.HOME.repository.FavoritoRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin/viviendas")
public class AdminViviendaController {

    private final ViviendaService viviendaService;
    private final FavoritoRepository favoritoRepository;

    public AdminViviendaController(
            ViviendaService viviendaService,
            FavoritoRepository favoritoRepository
    ) {
        this.viviendaService = viviendaService;
        this.favoritoRepository = favoritoRepository;
    }

    // ===================== LISTAR =====================
    @GetMapping
    public String listarViviendas(Model model) {

        List<Vivienda> viviendas = viviendaService.findAll();
        List<Favorito> favoritos = favoritoRepository.findAll();

        List<Long> favoritosIds = favoritos.stream()
                .map(f -> f.getVivienda().getId())
                .collect(Collectors.toList());

        model.addAttribute("viviendas", viviendas);
        model.addAttribute("favoritosIds", favoritosIds);

        return "admin/viviendas/listar";
    }

    // ===================== NUEVO =====================
    @GetMapping("/nuevo")
    public String nuevaVivienda(Model model) {
        model.addAttribute("vivienda", new Vivienda());
        return "registro_vivienda";
    }

    // ===================== GUARDAR =====================
@PostMapping("/guardar")
public String guardarVivienda(
        @ModelAttribute Vivienda vivienda,
        @RequestParam("imagenesFiles") MultipartFile[] imagenesFiles
) {

    if (imagenesFiles != null && imagenesFiles.length > 0) {
        try {
            String carpeta = "src/main/resources/static/uploads/viviendas/";
            List<String> nombres = new ArrayList<>();

            for (MultipartFile img : imagenesFiles) {
                if (!img.isEmpty()) {
                    String nombreArchivo = UUID.randomUUID() + "_" + img.getOriginalFilename();
                    Path ruta = Paths.get(carpeta + nombreArchivo);
                    Files.copy(img.getInputStream(), ruta, StandardCopyOption.REPLACE_EXISTING);
                    nombres.add(nombreArchivo);
                }
            }

            vivienda.setImagenes(String.join(",", nombres));

        } catch (IOException e) {
            throw new RuntimeException("Error al guardar imágenes", e);
        }
    }

    viviendaService.save(vivienda);
    return "redirect:/admin/viviendas";
}


     @GetMapping("/favoritos/eliminar/{id}")
    public String eliminarFavorito(@PathVariable Long id) {

        favoritoRepository.findByViviendaId(id)
                .ifPresent(favoritoRepository::delete);

        return "redirect:/admin/viviendas";
    }
    
    @GetMapping("/editar/{id}")
    public String editarVivienda(@PathVariable Long id, Model model) {

        Vivienda vivienda = viviendaService.findById(id);

        if (vivienda == null) {
            return "redirect:/admin/viviendas";
        }

        model.addAttribute("vivienda", vivienda);
        return "admin/viviendas/editar";
    }

@PostMapping("/actualizar")
public String actualizarVivienda(
        @RequestParam("id") Long id,
        @ModelAttribute Vivienda vivienda,
        @RequestParam(value = "imagenesFiles", required = false) MultipartFile[] imagenesFiles
) {

    Vivienda viviendaDB = viviendaService.findById(id);
    if (viviendaDB == null) return "redirect:/admin/viviendas";

    viviendaDB.setDireccion(vivienda.getDireccion());
    viviendaDB.setLocalidad(vivienda.getLocalidad());
    viviendaDB.setEstadoInmueble(vivienda.getEstadoInmueble());
    viviendaDB.setTipo(vivienda.getTipo());
    viviendaDB.setMetrosCuadrados(vivienda.getMetrosCuadrados());
    viviendaDB.setHabitaciones(vivienda.getHabitaciones());
    viviendaDB.setBanos(vivienda.getBanos());
    viviendaDB.setPrecio(vivienda.getPrecio());
    viviendaDB.setValorPropiedad(vivienda.getValorPropiedad());
    viviendaDB.setValorConstruccion(vivienda.getValorConstruccion());

    if (imagenesFiles != null && imagenesFiles.length > 0) {
        try {
            String carpeta = "src/main/resources/static/uploads/viviendas/";
            List<String> nuevas = new ArrayList<>();

            for (MultipartFile img : imagenesFiles) {
                if (!img.isEmpty()) {
                    String nombre = UUID.randomUUID() + "_" + img.getOriginalFilename();
                    Files.copy(img.getInputStream(),
                            Paths.get(carpeta + nombre),
                            StandardCopyOption.REPLACE_EXISTING);
                    nuevas.add(nombre);
                }
            }

            String existentes = viviendaDB.getImagenes();
            if (existentes != null && !existentes.isEmpty()) {
                nuevas.addAll(0, Arrays.asList(existentes.split(",")));
            }

            viviendaDB.setImagenes(String.join(",", nuevas));

        } catch (IOException e) {
            throw new RuntimeException("Error al actualizar imágenes", e);
        }
    }

    viviendaService.save(viviendaDB);
    return "redirect:/admin/viviendas";
}



    // ===================== ELIMINAR =====================
    @GetMapping("/eliminar/{id}")
    public String eliminarVivienda(@PathVariable Long id) {
        viviendaService.deleteById(id);
        return "redirect:/admin/viviendas";
    }

    // ===================== DETALLE =====================
   @GetMapping("/detalle/{id}")
   public String detalleVivienda(@PathVariable Long id, Model model) {

    Vivienda vivienda = viviendaService.findById(id);

    if (vivienda == null) {
        return "redirect:/admin/viviendas";
    }

    List<String> imagenes = new ArrayList<>();

    if (vivienda.getImagenes() != null && !vivienda.getImagenes().isEmpty()) {
        imagenes = Arrays.asList(vivienda.getImagenes().split(","));
    }

    model.addAttribute("vivienda", vivienda);
    model.addAttribute("imagenes", imagenes);

    return "admin/viviendas/detalle";
}

}
