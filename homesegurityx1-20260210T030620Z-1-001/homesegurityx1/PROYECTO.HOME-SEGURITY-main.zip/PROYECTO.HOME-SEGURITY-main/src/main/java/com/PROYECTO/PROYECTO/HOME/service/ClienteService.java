package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Cliente;
import java.util.List;

public interface ClienteService {

    Cliente guardar(Cliente cliente);

    List<Cliente> listar();

    Cliente buscarPorId(Long id);   

    List<Cliente> buscarFiltros(Integer idUsuario, String tipoCliente, String estado);
}
