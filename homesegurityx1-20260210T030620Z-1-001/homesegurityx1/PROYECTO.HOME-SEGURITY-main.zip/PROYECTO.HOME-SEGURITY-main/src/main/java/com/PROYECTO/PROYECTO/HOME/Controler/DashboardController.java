package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Pago;
import com.PROYECTO.PROYECTO.HOME.repository.CitasRepository;
import com.PROYECTO.PROYECTO.HOME.repository.PagoRepository;
import com.PROYECTO.PROYECTO.HOME.service.UsuarioService;
import com.PROYECTO.PROYECTO.HOME.service.ViviendaService;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class DashboardController {

    private final ViviendaService viviendaService;
    private final UsuarioService usuarioService;
    private final CitasRepository citaRepository;
    private final PagoRepository pagoRepository;

    public DashboardController(
            ViviendaService viviendaService,
            UsuarioService usuarioService,
            CitasRepository citaRepository,
            PagoRepository pagoRepository) {

        this.viviendaService = viviendaService;
        this.usuarioService = usuarioService;
        this.citaRepository = citaRepository;
        this.pagoRepository = pagoRepository;
    }

    // ================= DASHBOARD =================
    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        model.addAttribute("totalViviendas", viviendaService.findAll().size());
        model.addAttribute("totalUsuarios", usuarioService.listar().size());
        model.addAttribute("totalCitas", citaRepository.findAll().size());

        return "dashboard";
    }

    // ================= GESTIÓN DE USUARIOS =================
    // URL FINAL:
    // http://localhost:8080/usuario/gestion-usuarios
    @GetMapping("/usuario/gestion-usuarios")
    public String gestionUsuarios(Model model) {

        model.addAttribute("usuarios", usuarioService.listar());

        return "usuario/gestion-usuarios";
    }

    // ================= VER PAGOS (ADMIN) =================
    @Transactional
    @GetMapping("/admin/pagos")
    public String verPagos(Model model) {

        model.addAttribute("pagos", pagoRepository.findAll());
        return "admin/pagos";
    }

    // ================= VER FACTURA =================
    @Transactional
    @GetMapping("/admin/factura/{id}")
    public String verFactura(@PathVariable Long id, Model model) {

        Pago pago = pagoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));

        model.addAttribute("pago", pago);

        return "admin/factura";
    }
}
