package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Avaluos;
import java.util.List;

public interface AvaluosService {

    Avaluos save(Avaluos avaluo);

    List<Avaluos> findAll();

    Avaluos findById(Long id);

    void deleteById(Long id);
}
