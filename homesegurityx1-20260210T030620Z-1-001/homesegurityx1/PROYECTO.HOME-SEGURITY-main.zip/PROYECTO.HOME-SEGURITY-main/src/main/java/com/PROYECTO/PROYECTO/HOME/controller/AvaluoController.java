package com.PROYECTO.PROYECTO.HOME.controller;

import com.PROYECTO.PROYECTO.HOME.model.Avaluo;
import com.PROYECTO.PROYECTO.HOME.model.SolicitudAvaluo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/avaluos")
public class AvaluoController {

    // =========================
    // MEMORIA
    // =========================
    private List<Avaluo> listaAvaluos = new ArrayList<>();
    private List<SolicitudAvaluo> solicitudes = new ArrayList<>();

    private Long secuenciaId = 1L;
    private Long secuenciaSolicitud = 1L;

    // =========================
    // PRINCIPAL
    // =========================
    @GetMapping
    public String principal(Model model) {
        model.addAttribute("avaluos", listaAvaluos);
        return "avaluos/avaluos";
    }

    // =========================
    // LISTA NORMAL
    // =========================
    @GetMapping("/lista")
    public String lista(Model model) {
        model.addAttribute("avaluos", listaAvaluos);
        model.addAttribute("solicitudes", solicitudes);
        return "avaluos/lista";
    }

    // =========================
    // ====== AVALUOS FORM ======
    // =========================

    // 👉 ABRIR FORMULARIO
    @GetMapping("/form-general")
    public String formGeneral(Model model) {
        model.addAttribute("avaluo", new Avaluo());
        return "avaluos/avaluosForm/formulario";
    }

    // 👉 GUARDAR FORMULARIO
    @PostMapping("/guardar-form-general")
    public String guardarFormGeneral(
            @ModelAttribute Avaluo avaluo,
            @RequestParam(required = false) MultipartFile[] fotos
    ) {

        avaluo.setId(secuenciaId++);
        avaluo.setFecha(LocalDate.now());

        // evitar null
        if (avaluo.getValorEstimado() == null) {
            avaluo.setValorEstimado(0.0);
        }

        listaAvaluos.add(avaluo);

        return "redirect:/avaluos/form-lista";
    }

    // 👉 LISTA DEL FORM
    @GetMapping("/form-lista")
    public String formLista(Model model) {
        model.addAttribute("avaluos", listaAvaluos);
        return "avaluos/avaluosForm/lista";
    }

    // =========================
    // CREAR SIMPLE
    // =========================
    @GetMapping("/crear")
    public String crear() {
        return "avaluos/crear";
    }

    // =========================
    // GUARDAR SIMPLE
    // =========================
    @PostMapping("/guardar")
    public String guardar(
            @RequestParam Double areaTerreno,
            @RequestParam Double areaConstruccion,
            @RequestParam Integer antiguedad,
            @RequestParam String estadoInmueble,
            @RequestParam String tipoAvaluo,
            @RequestParam String descripcion
    ) {

        double valorFinal = calcularValor(
                areaConstruccion,
                areaTerreno,
                antiguedad,
                estadoInmueble,
                tipoAvaluo
        );

        Avaluo a = new Avaluo();
        a.setId(secuenciaId++);
        a.setAreaTerreno(areaTerreno);
        a.setAreaConstruccion(areaConstruccion);
        a.setAntiguedad(antiguedad);
        a.setEstadoInmueble(estadoInmueble);
        a.setTipoAvaluo(tipoAvaluo);
        a.setDescripcion(descripcion);
        a.setFecha(LocalDate.now());
        a.setValor(valorFinal);

        listaAvaluos.add(a);

        return "redirect:/avaluos/lista";
    }

    // =========================
    // VER DETALLE
    // =========================
    @GetMapping("/ver/{id}")
    public String ver(@PathVariable Long id, Model model) {

        for (Avaluo a : listaAvaluos) {
            if (a.getId().equals(id)) {

                double valorBase = 0;

                if (a.getAreaConstruccion() != null && a.getAreaTerreno() != null) {
                    valorBase = a.getAreaConstruccion() * 1200 +
                                a.getAreaTerreno() * 300;
                }

                model.addAttribute("a", a);
                model.addAttribute("valorBase", valorBase);
                model.addAttribute("valorFinal", a.getValor());

                return "avaluos/detalle";
            }
        }

        return "redirect:/avaluos/lista";
    }

    // =========================
    // ELIMINAR
    // =========================
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        listaAvaluos.removeIf(a -> a.getId().equals(id));
        return "redirect:/avaluos/lista";
    }

    // =========================
    // ========= SOLICITUDES =========
    // =========================

    @GetMapping("/pedir")
    public String pedir() {
        return "avaluos/pedirAvaluo";
    }

    @PostMapping("/solicitud")
    public String guardarSolicitud(
            @RequestParam Double areaTerreno,
            @RequestParam Double valorMetroTerreno,
            @RequestParam Double areaConstruccion,
            @RequestParam Double valorMetroConstruccion,
            @RequestParam String descripcion,
            Model model
    ) {

        SolicitudAvaluo s = new SolicitudAvaluo();
        s.setId(secuenciaSolicitud++);
        s.setAreaTerreno(areaTerreno);
        s.setValorMetroTerreno(valorMetroTerreno);
        s.setAreaConstruccion(areaConstruccion);
        s.setValorMetroConstruccion(valorMetroConstruccion);
        s.setDescripcion(descripcion);
        s.setFecha(LocalDate.now());

        solicitudes.add(s);

        model.addAttribute("mensaje", "Su solicitud de avalúo será respondida");
        return "avaluos/pedirAvaluo";
    }

    @GetMapping("/aceptar/{id}")
    public String aceptar(@PathVariable Long id) {

        SolicitudAvaluo encontrada = null;

        for (SolicitudAvaluo s : solicitudes) {
            if (s.getId().equals(id)) {
                encontrada = s;
                break;
            }
        }

        if (encontrada != null) {

            double valor =
                    encontrada.getAreaTerreno() * encontrada.getValorMetroTerreno() +
                    encontrada.getAreaConstruccion() * encontrada.getValorMetroConstruccion();

            Avaluo a = new Avaluo();
            a.setId(secuenciaId++);
            a.setFecha(LocalDate.now());
            a.setValor(valor);
            a.setDescripcion(encontrada.getDescripcion());

            listaAvaluos.add(a);
            solicitudes.remove(encontrada);
        }

        return "redirect:/avaluos/lista";
    }

    @GetMapping("/rechazar/{id}")
    public String rechazar(@PathVariable Long id) {
        solicitudes.removeIf(s -> s.getId().equals(id));
        return "redirect:/avaluos/lista";
    }

    // =========================
    // CALCULO
    // =========================
    private double calcularValor(
            double areaConstruccion,
            double areaTerreno,
            int antiguedad,
            String estado,
            String tipo
    ) {

        double base = areaConstruccion * 1200 + areaTerreno * 300;

        if ("REGULAR".equalsIgnoreCase(estado)) base *= 0.9;
        if ("MALO".equalsIgnoreCase(estado)) base *= 0.75;
        if ("COMERCIAL".equalsIgnoreCase(tipo)) base *= 1.2;

        base -= antiguedad * 1000;

        return base;
    }
}
