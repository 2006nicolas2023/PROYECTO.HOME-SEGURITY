package com.PROYECTO.PROYECTO.HOME.repository;

import com.PROYECTO.PROYECTO.HOME.Entity.Citas;
import com.PROYECTO.PROYECTO.HOME.Entity.enums.EstadoCita;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CitasRepository extends JpaRepository<Citas, Long> {
    List<Citas> findByViviendaId(Long viviendaId);
    List<Citas> findByEstado(EstadoCita estado);
       int countByFecha(LocalDate fecha);
}
