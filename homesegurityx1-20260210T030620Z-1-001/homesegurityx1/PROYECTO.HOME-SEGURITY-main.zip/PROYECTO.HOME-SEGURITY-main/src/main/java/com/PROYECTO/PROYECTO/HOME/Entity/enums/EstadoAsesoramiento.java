package com.PROYECTO.PROYECTO.HOME.Entity.enums;

public enum EstadoAsesoramiento {
    EN_PROCESO,
    CONFIRMADA,
    REPROGRAMADA,
    CANCELADA
}
