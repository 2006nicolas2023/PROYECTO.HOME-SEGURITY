package com.PROYECTO.PROYECTO.HOME.service;

import com.PROYECTO.PROYECTO.HOME.Entity.Citas;
import com.PROYECTO.PROYECTO.HOME.repository.CitasRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class CitaService {

    private final CitasRepository citaRepository;

    public CitaService(CitasRepository citaRepository) {
        this.citaRepository = citaRepository;
    }

   
    public Citas crearCitaValidada(Citas c) {
        LocalDate hoy = LocalDate.now();
        if (c.getFecha() == null) throw new IllegalArgumentException("Fecha requerida");
        if (c.getFecha().isBefore(hoy)) throw new IllegalArgumentException("La fecha debe ser hoy o posterior.");

        LocalDate bloqueoInicio = LocalDate.of(2025,12,23);
        LocalDate bloqueoFin = LocalDate.of(2026,1,23);
        if (!c.getFecha().isBefore(bloqueoInicio) && !c.getFecha().isAfter(bloqueoFin)) {
            throw new IllegalArgumentException("No hay citas disponibles entre 23-12-2025 y 23-01-2026.");
        }

        LocalTime hora = c.getHora();
        if (hora == null) throw new IllegalArgumentException("Hora requerida");
        LocalTime inicio = LocalTime.of(8,0);
        LocalTime fin = LocalTime.of(17,0);
        if (hora.isBefore(inicio) || hora.isAfter(fin)) {
            throw new IllegalArgumentException("Hora fuera de rango (08:00 - 17:00).");
        }

        return citaRepository.save(c);
    }

 

    
    public int countByFecha(LocalDate fecha) {
        return citaRepository.countByFecha(fecha);
    }

    public List<Citas> listarTodos() {
        return citaRepository.findAll();
    }

    public int citasHoy() {
        return citaRepository.countByFecha(LocalDate.now());
    }
}
