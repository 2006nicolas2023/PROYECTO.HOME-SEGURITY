package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Perito;
import com.PROYECTO.PROYECTO.HOME.service.PeritoService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/peritos")
@CrossOrigin(origins = "*")
public class PeritoController {

    private final PeritoService peritoService;

    public PeritoController(PeritoService peritoService) {
        this.peritoService = peritoService;
    }

    @PostMapping
    public ResponseEntity<Perito> crear(@RequestBody Perito perito) {
        return ResponseEntity.ok(peritoService.guardar(perito));
    }

    @GetMapping
    public ResponseEntity<List<Perito>> listar() {
        return ResponseEntity.ok(peritoService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Perito> buscar(@PathVariable Long id) {
        Perito perito = peritoService.buscarPorId(id);
        if (perito == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(perito);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        peritoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
