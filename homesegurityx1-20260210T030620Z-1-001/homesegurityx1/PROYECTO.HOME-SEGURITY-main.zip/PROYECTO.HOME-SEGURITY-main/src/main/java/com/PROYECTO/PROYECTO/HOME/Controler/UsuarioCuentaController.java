package com.PROYECTO.PROYECTO.HOME.Controler;

import com.PROYECTO.PROYECTO.HOME.Entity.Usuarios;
import com.PROYECTO.PROYECTO.HOME.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class UsuarioCuentaController {

    private final UsuarioService usuarioService;

    public UsuarioCuentaController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // ================= ACTUALIZAR CUENTA =================
    @PostMapping("/usuario/cuenta/actualizar")
    public String actualizarCuenta(
            @ModelAttribute("usuario") Usuarios usuarioForm,
            HttpSession session,
            Model model) {

        Usuarios usuarioSesion =
                (Usuarios) session.getAttribute("usuarioLogueado");

        if (usuarioSesion == null) {
            return "redirect:/login";
        }

        // MANTENER EL ID ORIGINAL
        usuarioForm.setIdUsuario(usuarioSesion.getIdUsuario());

        Usuarios actualizado =
                usuarioService.actualizar(usuarioSesion.getIdUsuario(), usuarioForm);

        // ACTUALIZAR SESIÓN
        session.setAttribute("usuarioLogueado", actualizado);

        model.addAttribute("usuario", actualizado);
        model.addAttribute("exito", "Datos actualizados correctamente");

        return "usuario/cuenta";
    }
}
